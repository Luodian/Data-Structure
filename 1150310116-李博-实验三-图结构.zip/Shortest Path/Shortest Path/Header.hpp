//
//  Header.hpp
//  Shortest Path
//
//  Created by 李博 on 11/04/2017.
//  Copyright © 2017 李博. All rights reserved.
//

#ifndef Header_h
#define Header_h

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <queue>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <ctime>
#include <set>
#include <map>
#include <stack>
const int maxn = 100005;
const int INF = 0x3f3f3f3f;
#define mem(x) memset(x,0,sizeof(x))
#define pii pair<int,int>

#endif /* Header_h */
