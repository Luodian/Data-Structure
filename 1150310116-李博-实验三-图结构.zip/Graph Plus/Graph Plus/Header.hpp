//
//  Header.hpp
//  Graph Plus
//
//  Created by 李博 on 04/04/2017.
//  Copyright © 2017 李博. All rights reserved.
//

#ifndef Header_h
#define Header_h

#include <iostream>
#include <cstring>
#include <algorithm>
#include <stack>
#include <vector>
#include <queue>
#include <cstdlib>
#include <fstream>
#include <cstdio>
#include <set>
#include <map>
const int maxn = 105;
#define mem(x) memset(x,0,sizeof(x))
#endif /* Header_h */
