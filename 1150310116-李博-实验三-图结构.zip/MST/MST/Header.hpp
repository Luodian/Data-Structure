//
//  Header.hpp
//  MST
//
//  Created by 李博 on 09/04/2017.
//  Copyright © 2017 李博. All rights reserved.
//

#ifndef Header_h
#define Header_h

#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <queue>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <set>
#include <map>

const int maxn = 100005;

#endif /* Header_h */
