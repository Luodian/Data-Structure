//
//  Header.hpp
//  Patricia
//
//  Created by 李博 on 24/05/2017.
//  Copyright © 2017 李博. All rights reserved.
//

#ifndef Header_h
#define Header_h

#include <iostream>
#include <cstring>
#include <algorithm>
#include <vector>
#include <set>
#include <cstdlib>
#include <fstream>
#include <list>
#include <map>

#endif /* Header_h */
